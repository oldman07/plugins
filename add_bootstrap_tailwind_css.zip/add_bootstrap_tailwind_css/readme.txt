===ADD Bootstrap and Tailwind Css ===
Contributors: habibalifoundation
Tags: bootstrap, tailwind, css, frontend, styles
Requires at least: 5.6
Tested up to: 6.6
Requires PHP: 7.2
Stable tag: 1.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html


Seamlessly integrate Bootstrap and Tailwind CSS into your WordPress site. 


